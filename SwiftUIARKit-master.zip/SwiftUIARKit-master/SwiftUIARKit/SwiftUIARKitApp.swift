//
//  SwiftUIARKitApp.swift
//  SwiftUIARKit
//
//  Created by Gualtiero Frigerio on 18/05/21.
//

import SwiftUI

@main
struct SwiftUIARKitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
